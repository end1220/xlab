﻿
// 单机模式

namespace Lite
{

	public class ConstDefine
	{
		public static bool STAND_ALONE = true;
	}

}

