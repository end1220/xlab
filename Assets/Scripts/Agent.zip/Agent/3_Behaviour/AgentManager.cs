
using Lite.Cmd;


namespace Lite.Bev
{
	public class AgentManager : IAgentManager<Agent>
	{
		
		public AgentManager()
		{
			
		}

	}

}
