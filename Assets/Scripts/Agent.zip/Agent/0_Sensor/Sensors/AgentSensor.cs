
using Lite.Strategy;

namespace Lite.Knowledge
{
	
	public class SimpleAgentSensor : ISensor
	{

		public override void Update()
		{
			// check env and set like this: owner.blackbaord.SetInt(key, value);
			//Log.Info("sensor updating...");
		}

	}
}