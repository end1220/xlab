﻿using Entitas;

[Core]
public sealed class PositionComponent : IComponent {

    public float x;
    public float y;
}